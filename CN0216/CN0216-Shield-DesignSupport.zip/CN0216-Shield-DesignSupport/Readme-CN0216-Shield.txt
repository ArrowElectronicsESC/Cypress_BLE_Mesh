Analog Devices Inc.
Design Support Package
CN-0216 Shield
11/15/2016
Rev. C

This file is designed to provide you with a brief overview of what is contained within the circuit note design support package.


**********************
*******Overview*******
**********************


CN-0216-Shield Design Support Package contains: 
	
	Link to Circuit Note for PMOD version of CN0216
	Link to Product Datasheets
	Link to Product Evaluation Boards and User Guides
	Schematics
	Bill of Materials
	Assembly Drawings
	Layout Files
	Gerber Layout Files	
	Link to Symbols and Footprints
	Link to Technical Support
	Link to Other Resources



**********************
***File Explanation**
**********************



Circuit Note - 	CN0216 describes the operation of the EVAL-CN0216-PMDZ board. 
		The theory of operation of the EVAL-CN0216-ARDZ board is similar. 

		CN0216: http://www.analog.com/CN0216


Product Datasheets - Links to all ADI component datasheets used in the circuit.  These files are provided as a PDF:

	AD7791        : http://www.analog.com/AD7791
	ADA4528-2     : http://www.analog.com/ADA4528-2
	ADP7102-5.0   : http://www.analog.com/ADP7102

	
CN0216-Shield 	Evaluation Board:
	 
	EVAL-CN0216-ARDZ: http://www.analog.com/EVAL-CN0216-ARDZ


Software for CN0216-Shield Evaluation Board:

	https://wiki.analog.com/resources/eval/user-guides/eval-adicup360/reference_designs/demo_cn0216
	
	
User Guide for CN0216-Shield Evaluation Board:

	https://wiki.analog.com/resources/eval/user-guides/eval-adicup360/hardware/cn0216
	
	
Bill of Materials for EVAL-CN0216-ARDZ:

	
	EVAL-CN0216-ARDZ-BOM-RevC.xls
	

	
Schematic Drawings (Cadence) for EVAL-CN0216-ARDZ:

	EVAL-CN0216-ARDZ-CadenceSchematic-RevC.pdf
	

Layout Drawings (Cadence) for EVAL-CN0216-ARDZ:

	EVAL-CN0216-ARDZ-CadenceLayout-RevC.brd
	EVAL-CN0216-ARDZ-CadenceLayout-RevC.pdf
	
	
Gerber Layout Files:

	EVAL-CN0216-ARDZ-GBR-RevC.zip

Cadence Library files:

	EVAL-CN0216-CadenceLibrary-RevC.zip

		
Symbols and Footprints:

	
AD7791:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/AD7791.html

ADA4528-2:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADA4528-2.html

ADP7102:
http://www.analog.com/en/design-center/packaging-quality-symbols-footprints/symbols-and-footprints/ADP7102.html


Technical Support -  If you require further technical assistance please contact us by phone, email, or our EngineerZone community.  http://www.analog.com/en/content/technical_support_page/fca.html



**********************
***Other Resources****
**********************


Resources that are not provided by Analog Devices, but could be helpful.


Gerber Viewer:  http://www.graphicode.com

Cadence Viewer: http://www.mentor.com/products/pcb-system-design/design-flows/Cadence/Cadence-pcb-viewer

Allegro Physical Viewer: http://www.cadence.com/products/pcb/Pages/downloads.aspx

Ultra Libraian : http://www.accelerated-designs.com/Beta/ULADI_CIS.exe

